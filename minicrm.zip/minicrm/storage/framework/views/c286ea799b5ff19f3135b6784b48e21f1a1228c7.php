<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">companies</div>

                <div class="card-header"><a href="<?php echo e(url('create-company')); ?>" class="btn btn-success">Create new Company</a></div>
                <table class="table table-striped">
                 <thead>
                 <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Logo</th>
                    <th>website</th>
                    <th>action</th>
                 </tr>
                 </thead>
                 <tbody>
                    
                   <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       <td><?php echo e($company->id); ?></td>
                       <td><?php echo e($company->name); ?></td>
                       <td><img src="<?php echo e(url('storage/app/public/'.$company->logo)); ?>" style="width:25px;height:25px"></td>
                       <td><?php echo e($company->website); ?></td>
                       <td><a href="<?php echo e(url('edit-company/'.$company->id)); ?>">Edit</a> | &nbsp;<a href="<?php echo e(url('delete-company/'.$company->id)); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                 </tbody>
              </table>
             <?php echo $list->render(); ?>
                   
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>