<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Employees</div>

                <div class="card-header"><a href="<?php echo e(url('create-employee')); ?>" class="btn btn-success">Create new Employee</a></div>
                <table class="table table-striped">
                 <thead>
                 <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Company</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                 </tr>
                 </thead>
                 <tbody>
                    
                   <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       <td><?php echo e($employee->id); ?></td>
                       <td><?php echo e($employee->firstname); ?></td>
                       <td><?php echo e($employee->lastname); ?></td>
                       <td><?php if(!empty($employee->company)){
                              $company=DB::table('companies')
                              ->select('companies.*')
                              ->where('id',$employee->company)
                              ->first();

                              echo $company->name;
                          }


                          ?>
                            
                        </td>
                       <td><?php echo e($employee->email); ?></td>
                       <td><?php echo e($employee->phone); ?></td>
                       <td><a href="<?php echo e(url('edit-employee/'.$employee->id)); ?>">Edit</a> | &nbsp;<a href="<?php echo e(url('delete-employee/'.$employee->id)); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                 </tbody>
              </table>
             <?php echo $list->render(); ?>
                   
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>