<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function companies()
    {
        $list=DB::table('companies')
        ->Paginate(10);
        return view('companies',['list'=>$list]);
    }

    public function create_company()
    {
        return view('create-company');
    }

    public function store_company(Request $request)
    {
        $this->validate($request,[
         'name'=>'required',
         'email'=>'email',
         'logo'=>'required|dimensions:min_width=100,min_height=100'
        ]);

        $file = $request->file('logo');

    // generate a new filename. getClientOriginalExtension() for the file extension
    $filename = 'profile-photo-' . time() . '.' . $file->getClientOriginalExtension();

    // save to storage/app/photos as the new $filename
    $path = $file->storeAs('public', $filename);

        $store=DB::table('companies')->insert([
            'name'=>$request->name,
            'email'=>$request->email,
            'logo'=>$filename,
            'website'=>$request->website
        ]);

        $list=DB::table('companies')
        ->Paginate(10);
        return view('companies',['list'=>$list]);
    }

    public function edit_company($id)
    {
        $show=DB::Table('companies')
        ->where('id',$id)
        ->first();

        return view('edit-company',['show'=>$show]);
    }

    public function edit_store_company(Request $request){

        $this->validate($request,[
         'name'=>'required',
         'email'=>'email',
         'logo'=>'required|dimensions:min_width=100,min_height=100'
        ]);

        $file = $request->file('logo');

    // generate a new filename. getClientOriginalExtension() for the file extension
    $filename = 'profile-photo-' . time() . '.' . $file->getClientOriginalExtension();

    // save to storage/app/photos as the new $filename
    $path = $file->storeAs('public', $filename);

        $company_id=$request->company_id;
        $store=DB::table('companies')
        ->where('id',$company_id)
        ->update([
            'name'=>$request->name,
            'email'=>$request->email,
            'logo'=>$filename,
            'website'=>$request->website
        ]);

        $list=DB::table('companies')
        ->Paginate(10);
        return view('companies',['list'=>$list]);
    }

    public function delete_company($id)
    {
        $show=DB::Table('companies')
        ->where('id',$id)
        ->delete();

        $list=DB::table('companies')
        ->Paginate(10);
        return view('companies',['list'=>$list]);
    }

    public function employees()
    {
        $list=DB::table('employees')
        ->Paginate(10);
        return view('employees',['list'=>$list]);
    }

    public function create_employee()
    {
        return view('create-employee');
    }

    public function store_employee(Request $request)
    {
        $this->validate($request,[
         'firstname'=>'required',
         'lastname'=>'required',
         'email'=>'email',
        ]);

        $store=DB::table('employees')->insert([
            'firstname'=>$request->firstname,
            'lastname'=>$request->lastname,
            'company'=>$request->company,
            'email'=>$request->email,
            'phone'=>$request->phone
        ]);

        $list=DB::table('employees')
        ->Paginate(10);
        return view('employees',['list'=>$list]);
    }

    public function edit_employee($id){
        $show=DB::Table('employees')
        ->where('id',$id)
        ->first();

        return view('edit-employee',['show'=>$show]);

    }

    public function edit_store_employee(Request $request){
        $this->validate($request,[
         'firstname'=>'required',
         'lastname'=>'required',
         'email'=>'email',
        ]);

        $employee_id=$request->employee_id;
        $store=DB::table('employees')
        ->where('id', $employee_id)
        ->update([
            'firstname'=>$request->firstname,
            'lastname'=>$request->lastname,
            'company'=>$request->company,
            'email'=>$request->email,
            'phone'=>$request->phone
        ]);

        $list=DB::table('employees')
        ->Paginate(10);
        return view('employees',['list'=>$list]);
    }

    public function delete_employee($id)
    {
        $show=DB::Table('employees')
        ->where('id',$id)
        ->delete();

        $list=DB::table('employees')
        ->Paginate(10);
        return view('employees',['list'=>$list]);
    }

}
