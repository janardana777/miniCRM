@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>

                <div style="text-align: center" class="row">
                    <div class="col-sm-6">
                    <a href="{{url('companies')}}" class="btn btn-primary">Companies List</a>
                    </div>

                    <div class="col-sm-6">
                    <a href="{{url('employees')}}" class="btn btn-primary">Employees List</a>
                    </div>
                    <br>
                    <br>
                </div>    
            </div>
        </div>
    </div>
</div>
@endsection
