@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Employees</div>

                <div class="card-header"><a href="{{url('create-employee')}}" class="btn btn-success">Create new Employee</a></div>
                <table class="table table-striped">
                 <thead>
                 <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Company</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                 </tr>
                 </thead>
                 <tbody>
                    
                   @foreach($list as $employee)
                    <tr>
                       <td>{{ $employee->id }}</td>
                       <td>{{ $employee->firstname }}</td>
                       <td>{{ $employee->lastname }}</td>
                       <td><?php if(!empty($employee->company)){
                              $company=DB::table('companies')
                              ->select('companies.*')
                              ->where('id',$employee->company)
                              ->first();

                              echo $company->name;
                          }


                          ?>
                            
                        </td>
                       <td>{{$employee->email}}</td>
                       <td>{{$employee->phone}}</td>
                       <td><a href="{{url('edit-employee/'.$employee->id)}}">Edit</a> | &nbsp;<a href="{{url('delete-employee/'.$employee->id)}}">Delete</a></td>
                    </tr>
                    @endforeach
                    
                 </tbody>
              </table>
             <?php echo $list->render(); ?>
                   
            </div>
        </div>
    </div>
</div>
@endsection
