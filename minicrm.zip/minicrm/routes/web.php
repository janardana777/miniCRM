<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/companies', 'HomeController@companies')->name('companies');
Route::get('/create-company', 'HomeController@create_company')->name('create-company');
Route::post('/create-company', 'HomeController@store_company')->name('create-company');

Route::get('/edit-company/{id}', 'HomeController@edit_company')->name('edit-company');
Route::post('/edit-company', 'HomeController@edit_store_company')->name('edit-company');
Route::get('/delete-company/{id}', 'HomeController@delete_company')->name('delete-company');

Route::get('/employees', 'HomeController@employees')->name('employees');
Route::get('/create-employee', 'HomeController@create_employee')->name('create-employee');
Route::post('/create-employee', 'HomeController@store_employee')->name('create-employee');
Route::get('/edit-employee/{id}', 'HomeController@edit_employee')->name('edit-employee');
Route::post('/edit-employee', 'HomeController@edit_store_employee')->name('edit-employee');
Route::get('/delete-employee/{id}', 'HomeController@delete_employee')->name('delete-employee');

